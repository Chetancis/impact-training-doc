var express = require('express');
var router = express.Router();
var basicAuth = require('basic-auth');

// if our user.js file is at app/models/user.js
var Student = require(__base +'models/student');
var Counter = require(__base +'models/counter');

//var getRollNo = module.parent.exports.getRollNo;
//var Student = module.parent.exports.Student;

var getRollNo = function (name) {
                    var ret = Counter.findOneAndUpdate({
                              query: { _id: name },
                              update: { $inc: { seq: 1 } },
                              option: { "upsert": true },
                              new: true
                            });

                    return ret.seq;
                };

var auth = function (req, res, next) {
  function unauthorized(res) {
    res.set('WWW-Authenticate', 'Basic realm=Authorization Required');
    return res.sendStatus(401);
  };

  var user = basicAuth(req);

  if (!user || !user.name || !user.pass) {
    return unauthorized(res);
  };

  if (user.name === 'admin' && user.pass === 'admin123') {
    return next();
  } else {
    return unauthorized(res);
  };
};

/* GET admin area. */
router.get('/', auth, function(req, res, next) {
  res.render('admin', { title: 'Admin Area' });
});

/* GET add student form. */
router.get('/create-student',auth, function(req, res, next) {
  res.render('create-student', { title: 'Create Student'});
});

/* POST add student form. */
router.post('/create-student', function(req, res, next) {
  var rollNO = getRollNo("student_roll_no");

  console.log('highets roll no : ',rollNO);
  
  new Student({
  	_id : '1',
    full_name : req.body.full_name,
    class_name : req.body.class_name,
    dob : new Date(req.body.dob),
    address : req.body.address,
    updated_at : Date.now()
  }).save( function( err, student, count ){
    if(err){
    	console.log("Err in save student : ",err);
    } else {
    	console.log("Student create successfully : ",student);	
    }    
    //res.redirect( '/' );
  });
  res.render('create-student', { title: 'Create Student'});
});

module.exports = router;