var express = require('express');
var router = express.Router();

/* GET admin area. */
router.get('/', function(req, res, next) {
  res.render('admin', { title: 'Admin Area' });
});

/* GET add student form. */
router.get('/create-student', function(req, res, next) {
  res.render('create-student', { title: 'New Student' });
});

module.exports = router;
