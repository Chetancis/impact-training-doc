var express = require('express');
var router = express.Router();
/*var counter = module.parent.Counter;
console.log('counter :', counter);*/

/* GET home page. */
router.get('/', function(req, res, next) {
  /*	counter.find({_id:"student_roll_no"},function(error,item){
  	if(err) {
        console.log('findOne error:', err);
    } else {
    	console.log('findOne item:', item);
    }
  });*/
  res.render('index', { title: 'Express' });
});

module.exports = router;
