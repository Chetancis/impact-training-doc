var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

//set mongodb connection by chetan
var mongoose = require('mongoose');

var StudentSchema = new mongoose.Schema({
                          roll_no: Number,
                          full_name: String,
                          class_name: String,
                          dob: Date,
                          address: String,
                          updated_at: { type: Date, default: Date.now },
                        });

var ResultSchema = new mongoose.Schema({
                          student_roll_no: Number,
                          subject_hindi_marks: Number,
                          subject_english_marks: Number,
                          subject_science_marks: Number,
                          subject_maths_marks: Number,
                          subject_social_science_marks: Number,
                          declare_date: Date,
                          
                          updated_at: { type: Date, default: Date.now },
                        });

var CounterSchema = new mongoose.Schema ({
                          _id: String,
                          seq: Number
                        });


var Counter = mongoose.model('Counter', CounterSchema);
var Student = mongoose.model('Student', StudentSchema);
var Result = mongoose.model('Result', ResultSchema);

mongoose.connect('mongodb://localhost/student-result');

module.exports.mongoose = mongoose;
module.exports.Counter = Counter;
module.exports.Student = Student;
module.exports.Result = Result;

Counter.find({_id:"student_roll_no"},function(err,item){
  if(err) {
      console.log('student_roll_no error:', err);
  } else {
    if(item.length == 0){
      // create a new counter
      var ctr = Counter({
        _id: 'student_roll_no',
        seq: 0
      });

      // save the counter
      ctr.save(function(err) {
        if (err) throw err;
        console.log('Counter created for student_roll_no!');
      });
    } else {
      console.log('items',item);
    }
  }
});

//end set mongodb connection by chetan

module.exports.getRollNo = function (name) {
                                         var ret = Counter.findOneAndUpdate(
                                                {
                                                  query: { _id: name },
                                                  update: { $inc: { seq: 1 } },
                                                  option: { "upsert": true },
                                                  new: true
                                                }
                                         );

                                         return ret.seq;
                                      };

var routes = require('./routes/index');
var users = require('./routes/users');
var admin = require('./routes/admin');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', routes);
app.use('/users', users);
app.use('/admin', admin);



// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
  app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});


module.exports = app;
