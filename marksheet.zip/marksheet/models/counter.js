//set mongodb connection by chetan
var mongoose = require('mongoose');

var CounterSchema = new mongoose.Schema ({
                          _id: String,
                          seq: Number
                        });

var Counter = mongoose.model('Counter', CounterSchema);

Counter.getRollNo = function (name) {
                    var ret = Counter.findOneAndUpdate({
                              query: { _id: name },
                              update: { $inc: { seq: 1 } },
                              option: { "upsert": true },
                              new: true
                            });

                    return ret.seq;
                };
//module.exports = getRollNo;

// make this available to our users in our Node applications
module.exports = Counter;
