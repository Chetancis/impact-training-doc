//set mongodb connection by chetan
var mongoose = require('mongoose');

var StudentSchema = new mongoose.Schema({
                          roll_no: Number,
                          full_name: String,
                          class_name: String,
                          dob: Date,
                          address: String,
                          updated_at: { type: Date, default: Date.now },
                        });

var Student = mongoose.model('Student', StudentSchema);

module.exports = Student;